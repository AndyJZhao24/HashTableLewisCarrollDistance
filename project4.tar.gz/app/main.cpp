#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <set>

#include "proj4.hpp"
#include "Wordset.hpp"


int main()
{
    return 0;
}

